# Corrected version: MoVoC (Findings of EMNLP 2025)

Corrected version of Teklehaymanot, Fazlija and Nejdl (2025),
*MoVoC: Morphology-Aware Subword Construction for Ge'ez Script Languages*,
Findings of EMNLP 2025, pp. 13131–13144,
<https://aclanthology.org/2025.findings-emnlp.706/>.

The results in the published version could not be reproduced. Following the
EMNLP 2025 programme chairs' advice, every result in this version is taken from
the reconstructed results in this repository. The correction notice after the
abstract summarises the changes, and Appendix D lists all of them.

| File | Content |
|---|---|
| `main.pdf` | The corrected paper |
| `main.tex`, `custom.bib` | LaTeX source (ACL format, XeLaTeX) |
| `tables/` | Tables 1–7, generated from this repository; `provenance.json` records the source of each |
| `scripts/make_correction_tables.py` | Regenerates `tables/` from the repository |
| `scripts/check_numbers.py` | Checks that every number in the paper traces to a repository file |
| `CORRECTION_INSTRUCTIONS.md` | Full procedure, sources and acceptance checks |
| `ANTHOLOGY_CHANGE_SUMMARY.txt` | Change summary for the ACL Anthology revision |
| `acl.sty`, `acl_natbib.bst` | ACL style files (github.com/acl-org/acl-style-files) |
| `fonts/` | Noto Serif Ethiopic, SIL Open Font License 1.1 (`fonts/OFL.txt`) |

## Rebuild

From the repository root:

```bash
python v2/paper/corrected_emnlp2025/scripts/make_correction_tables.py \
       --repo . --out v2/paper/corrected_emnlp2025/tables
cd v2/paper/corrected_emnlp2025
latexmk -xelatex main.tex
python scripts/check_numbers.py --repo ../../.. --paper .
```

Tables 2–4 are copied verbatim from `v2/paper/manuscript/tables/` and
`v2/archive/table3_intrinsic_v1_original/`. Table 3 uses the August 2026 run
set (9 runs, seeds 42/43/44, none excluded). The figures in `v2/table3/*.md`
are not used, because those runs include interpolated and pending values and
have no per-run records.
